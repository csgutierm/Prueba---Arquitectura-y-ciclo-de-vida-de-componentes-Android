package com.desafiolatam.coroutines

/*
INSERT INTO task VALUES
(1,"Circumnavigated a billion", "Circumnavigated a billion trillion at the edge of forever tingling of the spine science white dwarf"),
(2,"Descended from astronomers inconspicuous", "Descended from astronomers inconspicuous motes of rock and gas tesseract laws of physics citizens of distant epochs culture. Star stuff harvesting star light from which we spring white dwarf shores of the cosmic ocean rich in heavy atoms stirred by starlight."),
(3,"Tendrils of gossamer clouds Tunguska", "Tunguska event Apollonius of Perga science Vangelis gathered by gravity? Network of wormholes concept of the number one at the edge of forever brain is the seed of intelligence the ash of stellar alchemy tingling of the spine."),
(4,"Globular star cluster", "Globular star cluster Sea of Tranquility birth science great turbulent clouds a very small stage in a vast cosmic arena? "),
(5,"Across the centuries", "Gathered by gravity great turbulent clouds with pretty stories for which there's little good evidence the ash of stellar alchemy tesseract bits of moving fluff. Across the centuries permanence of the stars the carbon in our apple pies shores of the cosmic ocean invent the universe kindling the energy hidden in matter? How far away citizens of distant epochs the only home we've ever known concept of the number one made in the interiors of collapsing stars rich in heavy atoms."),
(6,"Cosmic fugue decipherment", "Cosmic fugue decipherment emerged into consciousness citizens of distant epochs tingling of the spine cosmos? Kindling the energy hidden in matter courage of our questions citizens of distant epochs Sea of Tranquility paroxysm of global death inconspicuous motes of rock and gas.")
*/
